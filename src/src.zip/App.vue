<template>
    <div id="app">
        <div class="wrap">
            <div id="attemptСounter"><h1>Ходов: {{counter}}</h1></div>
            <div class="gameBox" v-on:click="moveCell">
                <Cell v-for="(cell, index) in cells"  :id="cell" :value="cellsArray[index]" v-bind:key="cell"></Cell>
            </div>
        </div>
    </div>
</template>

<script>//es-lint disable
import Cell from './components/Cell.vue'

export default {
    name: 'app',
    components: {
        Cell
    },
    computed: {
        cellsArray: function () {
            return this.shuffle(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', ''])
        }
    },
    data: function() {
        return {
            cells: [
                '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16'
            ],
            counter: 0
        };
    },
    methods: {
        shuffle: function (a) {
            for (let i = a.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [a[i], a[j]] = [a[j], a[i]];

            }
            return a;
        },

        checkArray: function () { if (this.cellsArray === this.cellsArray.sort(function compare(a, b) {
            if (a == null)
                return -1;
            if (b == null)
                return 1;
            return a - b;
        }))alert("вы победили!")

        },
        moveCell(event) {

            let tg = event.target;

            let spareCell = null;

          if((tg.innerHTML !== '  ') && (tg.id >= 1 && tg.id <= 16)) {

                spareCell = tg.innerHTML;

                if(document.getElementById((Number(tg.id))-1).innerHTML == '  ') {
                    tg.innerHTML = document.getElementById((Number(tg.id))-1).innerHTML;
                    document.getElementById((Number(tg.id))-1).innerHTML = spareCell;
                    this.counter+=1;

                } else if (document.getElementById((Number(tg.id))-4).innerHTML == '  ') {
                    tg.innerHTML = document.getElementById((Number(tg.id))-4).innerHTML;
                    document.getElementById((Number(tg.id))-4).innerHTML = spareCell;
                    this.counter+=1;

                } else if (document.getElementById((Number(tg.id)) + 1).innerHTML == '  ') {
                    tg.innerHTML = document.getElementById((Number(tg.id)) + 1).innerHTML;
                    document.getElementById((Number(tg.id)) + 1).innerHTML = spareCell;
                    this.counter+=1;

                } else if (document.getElementById((Number(tg.id)) + 4).innerHTML == '  ') {
                    tg.innerHTML = document.getElementById((Number(tg.id)) + 4).innerHTML;
                    document.getElementById((Number(tg.id)) + 4).innerHTML = spareCell;
                    this.counter+=1;
                }


            }
        }

        //moveCell
    }
}
</script>

<style lang="scss">
    body{
        background-color: #EFE0A5;


    #app
    {
        width: fit-content;
        height: fit-content;
        margin: auto;
        background-color: #FADF2F;
            .wrap {
                width: fit-content;
                height: fit-content;


                #attemptСounter {
                    margin: auto;
                    width: fit-content;
                }
                .gameBox {
                    display: grid;
                    grid-template-rows: 1fr 1fr 1fr;
                    grid-template-columns: 1fr 1fr 1fr 1fr;
                    grid-gap: 10px;
                    width: fit-content;
                    height: fit-content;
                    padding: 5px;
                }

            }
    }
    }

</style>
<!--
  position: absolute;
  left: 50%;
  transform: translate(0, 50%);
  margin: 0;
  padding: 0;-->