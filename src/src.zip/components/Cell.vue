<template>
    <div class="cell">
        {{value}}
    </div>
</template>

<script>
    export default {
        name: 'Cell',
        props: {
            value: {
                type: String,
                default: null
            }
        }
    }
</script>
<style scoped lang="scss">
    .cell {
        width: 150px;
        height: 150px;
        position: relative;
        border: 1px solid #B50C17;
        background: #047D41;
        color:  #EFE0A5 ;
        border-radius: 10px;
        text-align:center;
        font-size: 40px;
        font-family: "Segoe UI";
        cursor: default;
        justify-content: center;

    }

</style>
